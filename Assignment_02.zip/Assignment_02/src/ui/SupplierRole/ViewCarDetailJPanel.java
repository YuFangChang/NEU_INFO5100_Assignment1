package ui.SupplierRole;

import java.awt.CardLayout;
import ui.AdminRole.ManageManufJPanel;
import java.awt.Component;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import model.Car;

/**
 *
 * @author Mihir Mehta / Hechen Gao
 */
public class ViewCarDetailJPanel extends javax.swing.JPanel {

    private JPanel userProcessContainer;
    private Car car;
    public ViewCarDetailJPanel(JPanel upc, Car p) {
        initComponents();
        userProcessContainer = upc;
        car = p;
        txtSN.setText(String.valueOf(p.getSerialNum()));
        txtModelNum.setText(p.getModelNum());
        txtYear.setText(String.valueOf(p.getYear()));
        txtSeats.setText(String.valueOf(p.getSeatsNum()));
        txtDate.setText(p.getDate());
        txtCity.setText(p.getCity());
        checkBox.setSelected(p.isCurrentlyAvail());
        checkyne.setSelected(p.isYne());

    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnBack = new javax.swing.JButton();
        txtCity = new javax.swing.JTextField();
        lblTitle = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        txtModelNum = new javax.swing.JTextField();
        lblSN = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        lblModelNum = new javax.swing.JLabel();
        txtSN = new javax.swing.JTextField();
        lblModelYear = new javax.swing.JLabel();
        btnSave = new javax.swing.JButton();
        lblSeatsNum = new javax.swing.JLabel();
        lblCity = new javax.swing.JLabel();
        lblEDate = new javax.swing.JLabel();
        lblAvail = new javax.swing.JLabel();
        txtYear = new javax.swing.JTextField();
        txtSeats = new javax.swing.JTextField();
        lblmustN = new javax.swing.JLabel();
        lblmustN1 = new javax.swing.JLabel();
        lblAlert = new javax.swing.JLabel();
        checkBox = new javax.swing.JCheckBox();
        lblyne = new javax.swing.JLabel();
        checkyne = new javax.swing.JCheckBox();

        setPreferredSize(new java.awt.Dimension(650, 600));

        btnBack.setText("<< Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        txtCity.setEditable(false);

        lblTitle.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblTitle.setText("View Passenger Car Details");

        txtDate.setEditable(false);

        txtModelNum.setEditable(false);

        lblSN.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblSN.setText("Serial Number:");

        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        lblModelNum.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblModelNum.setText("Model Number:");

        txtSN.setEditable(false);

        lblModelYear.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblModelYear.setText("Model Year:");

        btnSave.setText("Save");
        btnSave.setEnabled(false);
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        lblSeatsNum.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblSeatsNum.setText("Seats Number:");

        lblCity.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblCity.setText("City:");

        lblEDate.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblEDate.setText("Maintenance Certificate Expiration Date:");

        lblAvail.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblAvail.setText("Currently Available:");

        txtYear.setEditable(false);

        txtSeats.setEditable(false);

        lblmustN.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblmustN.setForeground(new java.awt.Color(255, 0, 0));

        lblmustN1.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblmustN1.setForeground(new java.awt.Color(255, 0, 0));

        lblAlert.setFont(new java.awt.Font("Arial", 1, 11)); // NOI18N
        lblAlert.setForeground(new java.awt.Color(255, 0, 0));

        checkBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkBoxActionPerformed(evt);
            }
        });

        lblyne.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lblyne.setText("Maintenance Certificate is expired ?");

        checkyne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkyneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnBack)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(150, 150, 150)
                                        .addComponent(lblSeatsNum))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lblEDate)
                                        .addComponent(lblCity)
                                        .addComponent(lblAvail)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(txtCity, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtSeats, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(checkBox)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblyne)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(checkyne))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblModelYear)
                                    .addComponent(lblSN))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtSN, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtYear, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblmustN, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblmustN1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(232, 232, 232)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnSave, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblAlert, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(177, 177, 177)
                        .addComponent(lblTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addComponent(lblModelNum)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtModelNum, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblTitle)
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblModelNum)
                            .addComponent(txtModelNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblSN)
                            .addComponent(txtSN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblModelYear)
                                .addComponent(txtYear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblmustN, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblmustN1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblSeatsNum)
                                .addComponent(txtSeats, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEDate)
                            .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblyne)
                            .addComponent(checkyne))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblCity)
                            .addComponent(txtCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblAvail)
                            .addComponent(checkBox))
                        .addGap(39, 39, 39)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnUpdate)
                                .addGap(18, 18, 18)
                                .addComponent(btnSave))
                            .addComponent(lblAlert, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(btnBack))
                .addContainerGap(173, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed

        backAction();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed

        //txtId.setEditable(true);
        txtModelNum.setEditable(true);
        txtYear.setEditable(true);
        txtSeats.setEditable(true);
        txtDate.setEditable(true);
        txtCity.setEditable(true);
        checkBox.setEnabled(true);
        btnSave.setEnabled(true);
        checkyne.setEnabled(true);
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed

        car.setModelNum(txtModelNum.getText());
        car.setYear(Integer.parseInt(txtYear.getText()));
        car.setSeatsNum(Integer.parseInt(txtSeats.getText()));
        car.setDate(txtDate.getText());
        car.setCity(txtCity.getText());
        car.setCurrentlyAvail(checkBox.isSelected());
        car.setYne(checkyne.isSelected());
        JOptionPane.showMessageDialog(this, "Updated.");
    }//GEN-LAST:event_btnSaveActionPerformed

    private void checkBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkBoxActionPerformed

    private void checkyneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkyneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkyneActionPerformed

      private void backAction() {
        userProcessContainer.remove(this);
        Component[] componentArray = userProcessContainer.getComponents();
        Component component = componentArray[componentArray.length - 1];
        ManageCarCatalogJPanel manageProductCatalogJPanel = (ManageCarCatalogJPanel) component;
        manageProductCatalogJPanel.refreshTable();
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JCheckBox checkBox;
    private javax.swing.JCheckBox checkyne;
    private javax.swing.JLabel lblAlert;
    private javax.swing.JLabel lblAvail;
    private javax.swing.JLabel lblCity;
    private javax.swing.JLabel lblEDate;
    private javax.swing.JLabel lblModelNum;
    private javax.swing.JLabel lblModelYear;
    private javax.swing.JLabel lblSN;
    private javax.swing.JLabel lblSeatsNum;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblmustN;
    private javax.swing.JLabel lblmustN1;
    private javax.swing.JLabel lblyne;
    private javax.swing.JTextField txtCity;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtModelNum;
    private javax.swing.JTextField txtSN;
    private javax.swing.JTextField txtSeats;
    private javax.swing.JTextField txtYear;
    // End of variables declaration//GEN-END:variables
}
