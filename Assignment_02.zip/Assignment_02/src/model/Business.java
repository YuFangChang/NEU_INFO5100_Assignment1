/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Ariel
 */
public class Business {
    
     MasterOrderList masterOrderList;
    ManufDirectory supplierDirectory;
    
    public Business(){
        masterOrderList = new MasterOrderList();
        supplierDirectory = new ManufDirectory();
        
    }

    public MasterOrderList getMasterOrderList() {
        return masterOrderList;
    }

    public void setMasterOrderList(MasterOrderList masterOrderList) {
        this.masterOrderList = masterOrderList;
    }

    public ManufDirectory getSupplierDirectory() {
        return supplierDirectory;
    }

    public void setSupplierDirectory(ManufDirectory supplierDirectory) {
        this.supplierDirectory = supplierDirectory;
    }

 
}
