/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author archil
 */
public class Car {

    
    private String manufName;     //manufacturer
    private int year;              //manufactured year
    private String modelNum;    //model number
    private int seatsNum;     //seats number
    private String date;    //maintenance certificate expiration date

    private int serialNum;      //serial number (Uber App)
    private String city;                              //the available car in given city
    private boolean currentlyAvail;     //currently received the order (Uber App)
   private boolean yne;  //maintenance certificate expiration date y/n
    
    private static int count = 0;

    @Override
    public String toString() {
        return modelNum; //To change body of generated methods, choose Tools | Templates.
    }

    public Car() {
        count++;
        serialNum = count;
    }

    public String getManufName() {
        return manufName;
    }

    public void setManufName(String manufName) {
        this.manufName = manufName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getModelNum() {
        return modelNum;
    }

    public void setModelNum(String modelNum) {
        this.modelNum = modelNum;
    }

    public int getSeatsNum() {
        return seatsNum;
    }

    public void setSeatsNum(int seatsNum) {
        this.seatsNum = seatsNum;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getSerialNum() {
        return serialNum;
    }

    public void setSerialNum(int serialNum) {
        this.serialNum = serialNum;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public boolean isCurrentlyAvail() {
        return currentlyAvail;
    }

    public void setCurrentlyAvail(boolean currentlyAvail) {
        this.currentlyAvail = currentlyAvail;
    }

    

    public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Car.count = count;
    }

    public boolean isYne() {
        return yne;
    }

    public void setYne(boolean yne) {
        this.yne = yne;
    }

  


}
