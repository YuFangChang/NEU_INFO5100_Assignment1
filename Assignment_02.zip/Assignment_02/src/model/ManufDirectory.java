/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author archil
 */
public class ManufDirectory {

    private List<Manuf> manufList;

    public ManufDirectory() {
        manufList = new ArrayList<Manuf>();
    }

    public List<Manuf> getManuflist() {
        return manufList;
    }

    public Manuf addManuf() {
        Manuf newManuf = new Manuf();
        manufList.add(newManuf);
        return newManuf;
    }

    public void removeManuf(Manuf m) {
        manufList.remove(m);
    }

    public Manuf searchManuf(String manufName) {
        for (Manuf manuf : manufList) {
            if (manuf.getManufName().equals(manufName)) {
                return manuf;
            }
        }
        return null;
    }
    

    
}
